﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using Notfullin326_ProizvodPrakt.Components.Model;

namespace Notfullin326_ProizvodPrakt
{
    public partial class App : Application
    {
        public static Notfullin_326PracticeEntities DB =  new Notfullin_326PracticeEntities();
        public static User LoggedUser;
    }
}   
