﻿using Notfullin326_ProizvodPrakt.Components.Model;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Notfullin326_ProizvodPrakt.Pages
{
    /// <summary>
    /// Логика взаимодействия для CharacterAddEditPage.xaml
    /// </summary>
    public partial class WeaponAddEditPage : Page
    {
        Weapon contextWeapon;
        public WeaponAddEditPage(Weapon weapon)
        {
            InitializeComponent();
            CbCalibr.ItemsSource = App.DB.Calibr.ToList();
            CbTypeWeapon.ItemsSource = App.DB.TypeWeapon.ToList();
            contextWeapon = weapon;
            DataContext = contextWeapon;
        }
        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            string errorMessage = "";
            if (string.IsNullOrWhiteSpace(contextWeapon.Name))
            {
                errorMessage += "Введите название\n";
            }
            if (string.IsNullOrWhiteSpace(contextWeapon.History))
            {
                errorMessage += "Введите историю\n";
            }
            if (contextWeapon.Calibr == null)
            {
                errorMessage += "Выберите калибр\n";
            }
            if (contextWeapon.Weight == null)
            {
                errorMessage += "Выберите вес\n";
            }
            if (contextWeapon.TypeWeapon == null)
            {
                errorMessage += "Выберите тип оружия\n";
            }
            if (contextWeapon.Image == null)
            {
                errorMessage += "Добавьте картинку\n";
            }
            if (string.IsNullOrWhiteSpace(errorMessage) == false)
            {
                MessageBox.Show(errorMessage);
                return;
            }
            if (contextWeapon.Id == 0)
            {
                contextWeapon.TypeArticleId = 1;
                App.DB.Weapon.Add(contextWeapon);
            }
            App.DB.SaveChanges();
            NavigationService.GoBack();

        }
        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

        private void BtnEditImage_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog();
            if (dialog.ShowDialog().GetValueOrDefault())
            {
                contextWeapon.Image = File.ReadAllBytes(dialog.FileName);
                DataContext = null;
                DataContext = contextWeapon;
            }
        }
    }
}