﻿using Notfullin326_ProizvodPrakt.Components.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Notfullin326_ProizvodPrakt.Pages
{
    /// <summary>
    /// Логика взаимодействия для CharactersPage.xaml
    /// </summary>
    public partial class WeaponsPage : Page
    {
        public WeaponsPage()
        {
            InitializeComponent();
            if (App.LoggedUser.Role.Id == 1 || App.LoggedUser.Role.Id == 2)
            {
                BtnAdd.Visibility = Visibility.Visible;
                BtnEdit.Visibility = Visibility.Visible;
                BtnDelete.Visibility = Visibility.Visible;
                BtnRestore.Visibility = Visibility.Visible;
            }
            LvWeapon.ItemsSource = App.DB.Weapon.ToList();
            CbTypeWeapon.ItemsSource = App.DB.TypeWeapon.ToList();
        }
        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new WeaponAddEditPage(new Weapon()));
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            var selectedWeapon = LvWeapon.SelectedItem as Weapon;
            if (selectedWeapon == null)
            {
                MessageBox.Show("Выберите оружие");
                return;
            }
            NavigationService.Navigate(new WeaponAddEditPage(selectedWeapon));
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var selectedWeapon = LvWeapon.SelectedItem as Weapon;
            if (selectedWeapon == null)
            {
                MessageBox.Show("Выберите оружие");
                return;
            }
            selectedWeapon.IsDelete = true;
            App.DB.SaveChanges();
            Refresh();
        }
        private void BtnRestore_Click(object sender, RoutedEventArgs e)
        {
            var selectedWeapon = LvWeapon.SelectedItem as Weapon;
            if (selectedWeapon == null)
            {
                MessageBox.Show("Выберите оружие");
                return;
            }
            selectedWeapon.IsDelete = false;
            App.DB.SaveChanges();
            Refresh();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            Refresh();
        }
        private void Refresh()
        {

            IEnumerable<Weapon> filterService = App.DB.Weapon;
            if (CbTypeWeapon.SelectedIndex == 0)
                filterService = filterService.Where(x => x.TypeWeaponId == 1).ToList();
            else if (CbTypeWeapon.SelectedIndex == 1)
                filterService = filterService.Where(x => x.TypeWeaponId == 2).ToList();

            if (TbSearch.Text.Length > 0)
            {
                filterService = filterService.Where(x => x.Name.ToLower().StartsWith(TbSearch.Text.ToLower()));
            }
            LvWeapon.ItemsSource = filterService.ToList();

        }

        private void TbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            Refresh();
        }

        private void BtnView_Click(object sender, RoutedEventArgs e)
        {
            var selectedWeapon = LvWeapon.SelectedItem as Weapon;
            if (selectedWeapon == null)
            {
                MessageBox.Show("Выберите оружие");
                return;
            }
            if (selectedWeapon.IsDelete == true)
            {
                MessageBox.Show("Статья больше неактуальна");
                return;
            }
            NavigationService.Navigate(new WeaponViewPage(selectedWeapon));
        }

        private void CbTypeWeapon_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Refresh();
        }

    }
}
