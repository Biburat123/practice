﻿using Notfullin326_ProizvodPrakt.Components.Model;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Notfullin326_ProizvodPrakt.Pages
{
    /// <summary>
    /// Логика взаимодействия для ArmorAddEditPage.xaml
    /// </summary>
    public partial class ArmorAddEditPage : Page
    {
        Armor contextArmor;
        public ArmorAddEditPage(Armor armor)
        {
            InitializeComponent();
            CbMaterial.ItemsSource = App.DB.Material.ToList();
            CbClass.ItemsSource = App.DB.Class.ToList();
            contextArmor = armor;
            DataContext = contextArmor;
        }
        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            string errorMessage = "";
            if (string.IsNullOrWhiteSpace(contextArmor.Name))
            {
                errorMessage += "Введите название\n";
            }
            if (string.IsNullOrWhiteSpace(contextArmor.Description))
            {
                errorMessage += "Введите описание\n";
            }
            if (contextArmor.Durability == null)
            {
                errorMessage += "Выберите прочность\n";
            }
            if (contextArmor.Weight == null)
            {
                errorMessage += "Выберите вес\n";
            }
            if (contextArmor.Material == null)
            {
                errorMessage += "Выберите материал\n";
            }
            if (contextArmor.Class == null)
            {
                errorMessage += "Выберите класс\n";
            }
            if (contextArmor.image == null)
            {
                errorMessage += "Добавьте картинку\n";
            }
            if (string.IsNullOrWhiteSpace(errorMessage) == false)
            {
                MessageBox.Show(errorMessage);
                return;
            }
            if (contextArmor.Id == 0)
            {
                contextArmor.TypeArticleId = 3;
                App.DB.Armor.Add(contextArmor);
            }
            App.DB.SaveChanges();
            NavigationService.GoBack();

        }
        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

        private void BtnEditImage_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog();
            if (dialog.ShowDialog().GetValueOrDefault())
            {
                contextArmor.image = File.ReadAllBytes(dialog.FileName);
                DataContext = null;
                DataContext = contextArmor;
            }
        }

        private void CbMaterialId_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CbMaterial.SelectedIndex == 0)
            {
                CbMaterial.ItemsSource = App.DB.Armor.Where(x => x.MaterialId == 1).ToList();
            }
            else if (CbMaterial.SelectedIndex == 1)
            {
                CbMaterial.ItemsSource = App.DB.Armor.Where(x => x.MaterialId == 2).ToList();
            }
        }
    }
}
