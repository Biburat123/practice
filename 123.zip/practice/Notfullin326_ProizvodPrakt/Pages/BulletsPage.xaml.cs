﻿using Notfullin326_ProizvodPrakt.Components.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Notfullin326_ProizvodPrakt.Pages
{
    /// <summary>
    /// Логика взаимодействия для MapsPage.xaml
    /// </summary>
    public partial class BulletsPage : Page
    {
        public BulletsPage()
        {
            InitializeComponent();
            if (App.LoggedUser.Role.Id == 1 || App.LoggedUser.Role.Id == 2)
            {
                BtnAdd.Visibility = Visibility.Visible;
                BtnEdit.Visibility = Visibility.Visible;
                BtnDelete.Visibility = Visibility.Visible;
                BtnRestore.Visibility = Visibility.Visible;
            }
            LvBullets.ItemsSource = App.DB.Bullet.ToList();
        }
        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new BulletAddEditPage(new Bullet()));
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            var selectedBullet = LvBullets.SelectedItem as Bullet;
            if (selectedBullet == null)
            {
                MessageBox.Show("Выберите патрон");
                return;
            }
            NavigationService.Navigate(new BulletAddEditPage(selectedBullet));
        }
        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var selectedBullet = LvBullets.SelectedItem as Bullet;
            if (selectedBullet == null)
            {
                MessageBox.Show("Выберите патрон");
                return;
            }
            selectedBullet.IsDelete = true;
            App.DB.SaveChanges();
            Refresh();
        }
        private void BtnRestore_Click(object sender, RoutedEventArgs e)
        {
            var selectedBullet = LvBullets.SelectedItem as Bullet;
            if (selectedBullet == null)
            {
                MessageBox.Show("Выберите патрон");
                return;
            }
            selectedBullet.IsDelete = false;
            App.DB.SaveChanges();
            Refresh();
        }
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            Refresh();
        }
        private void Refresh()
        {
            if (string.IsNullOrWhiteSpace(TbSearch.Text))
            {
                LvBullets.ItemsSource = App.DB.Bullet.ToList();
            }
            else
            {
                LvBullets.ItemsSource = App.DB.Bullet.Where(a => a.Name.ToLower().Contains(TbSearch.Text.ToLower())).ToList();
            }
        }

        private void TbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            Refresh();
        }

        private void BtnView_Click(object sender, RoutedEventArgs e)
        {
            var selectedBullet = LvBullets.SelectedItem as Bullet;
            if (selectedBullet == null)
            {
                MessageBox.Show("Выберите патрон");
                return;
            }
            if (selectedBullet.IsDelete == true)
            {
                MessageBox.Show("Статья больше неактуальна");
                return;
            }
            NavigationService.Navigate(new BulletViewPage1(selectedBullet));
        }

    }
}
