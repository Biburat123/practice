﻿using Notfullin326_ProizvodPrakt.Components.Model;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Notfullin326_ProizvodPrakt.Pages
{
    /// <summary>
    /// Логика взаимодействия для MapAddEditPage.xaml
    /// </summary>
    public partial class BulletAddEditPage : Page
    {
        Bullet contextBullet;
        public BulletAddEditPage(Bullet bullet)
        {
            InitializeComponent();
            contextBullet = bullet;
            DataContext = contextBullet;
        }
        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            string errorMessage = "";
            if (string.IsNullOrWhiteSpace(contextBullet.Name))
            {
                errorMessage += "Введите название\n";
            }
            if (string.IsNullOrWhiteSpace(contextBullet.History))
            {
                errorMessage += "Введите историю\n";
            }
            if (contextBullet.Damage == null)
            {
                errorMessage += "Введите урон\n";
            }
            if (contextBullet.Speed == null)
            {
                errorMessage += "Введите скорость\n";
            }
            if (contextBullet.Penetration == null)
            {
                errorMessage += "Введите проникающую способность\n";
            }
            if (contextBullet.Image == null)
            {
                errorMessage += "Добавьте картинку\n";
            }
            if (string.IsNullOrWhiteSpace(errorMessage) == false)
            {
                MessageBox.Show(errorMessage);
                return;
            }
            if (contextBullet.Id == 0)
            {
                contextBullet.TypeArticleId = 4;
                App.DB.Bullet.Add(contextBullet);
            }
            App.DB.SaveChanges();
            NavigationService.GoBack();

        }
        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

        private void BtnEditImage_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog();
            if (dialog.ShowDialog().GetValueOrDefault())
            {
                contextBullet.Image = File.ReadAllBytes(dialog.FileName);
                DataContext = null;
                DataContext = contextBullet;
            }
        }
    }
}
