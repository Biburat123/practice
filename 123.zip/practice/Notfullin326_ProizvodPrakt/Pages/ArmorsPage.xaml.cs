﻿using Notfullin326_ProizvodPrakt.Components.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Notfullin326_ProizvodPrakt.Pages
{
    /// <summary>
    /// Логика взаимодействия для ArmorsPage.xaml
    /// </summary>
    public partial class ArmorsPage : Page
    {
        public ArmorsPage()
        {
            InitializeComponent();
            if (App.LoggedUser.Role.Id == 1 || App.LoggedUser.Role.Id == 2)
            {
                BtnAdd.Visibility = Visibility.Visible;
                BtnEdit.Visibility = Visibility.Visible;
                BtnDelete.Visibility = Visibility.Visible;
                BtnRestore.Visibility = Visibility.Visible;
            }
            LvArmor.ItemsSource = App.DB.Armor.ToList();
            CbMaterial.ItemsSource = App.DB.Material.ToList();
        }
        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new ArmorAddEditPage(new Armor()));
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            var selectedArmor = LvArmor.SelectedItem as Armor;
            if (selectedArmor == null)
            {
                MessageBox.Show("Выберите бронежилет");
                return;
            }
            NavigationService.Navigate(new ArmorAddEditPage(selectedArmor));
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var selectedArmor = LvArmor.SelectedItem as Armor;
            if (selectedArmor == null)
            {
                MessageBox.Show("Выберите бронежилет");
                return;
            }
            selectedArmor.IsDelete = true;
            App.DB.SaveChanges();
            Refresh();
        }
        private void BtnRestore_Click(object sender, RoutedEventArgs e)
        {
            var selectedArmor = LvArmor.SelectedItem as Armor;
            if (selectedArmor == null)
            {
                MessageBox.Show("Выберите бронежилет");
                return;
            }
            selectedArmor.IsDelete = false;
            App.DB.SaveChanges();
            Refresh();
        }
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            Refresh();
        }
        private void Refresh()
        {

            IEnumerable<Armor> filterService = App.DB.Armor;
            if (CbMaterial.SelectedIndex == 0)
                filterService = filterService.Where(x => x.MaterialId == 1).ToList();
            else if (CbMaterial.SelectedIndex == 1)
                filterService = filterService.Where(x => x.MaterialId == 2).ToList();

            if (TbSearch.Text.Length > 0)
            {
                filterService = filterService.Where(x => x.Name.ToLower().StartsWith(TbSearch.Text.ToLower()) || x.Material.Name.ToLower().StartsWith(TbSearch.Text.ToLower()));
            }
            LvArmor.ItemsSource = filterService.ToList();

        }

        private void TbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            Refresh();
        }

        private void BtnView_Click(object sender, RoutedEventArgs e)
        {
            var selectedArmor = LvArmor.SelectedItem as Armor;
            if (selectedArmor == null)
            {
                MessageBox.Show("Выберите бронежилет");
                return;
            }
            if (selectedArmor.IsDelete == true)
            {
                MessageBox.Show("Статья больше неактуальна");
                return;
            }
            NavigationService.Navigate(new ArmorViewPage(selectedArmor));
        }

        private void CbMaterialId_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Refresh();
        }

    }
}
